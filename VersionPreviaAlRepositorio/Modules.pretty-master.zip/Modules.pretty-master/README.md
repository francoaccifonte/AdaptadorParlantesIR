## Library Contents
This library contains footprints (.kicad_mod files) for SoM (System on Module), typically functional modules integrated onto a separate PCB

## Note

**This repository is now marked as read-only and will no longer accept pull requests. To contribute, refer to the new footprints library at https://github.com/kicad/kicad-footprints**
